from django.db import models

# Create your models here.
#first_name, last_name, email, phone, designation, department, salary, joining_date, address 

class Employee(models.Model):
    first_name = models.CharField(max_length=255, null=True)
    last_name = models.CharField(max_length=255, null=True)
    email = models.EmailField(null=True)
    phone = models.CharField(null=True)
    designation = models.CharField(max_length=255, null=True)
    department = models.CharField(max_length=255, null=True)
    salary = models.PositiveIntegerField(null=True)
    joining_date = models.DateTimeField(auto_now_add=True, null=True)
    address = models.TextField(null=True)
    
    def __str__(self):
        return f"{self.first_name}---{self.designation}"
