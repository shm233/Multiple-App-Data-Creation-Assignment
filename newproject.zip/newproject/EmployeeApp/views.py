from django.shortcuts import render, redirect
from EmployeeApp.models import *

# Create your views here.

def employee_view(request):
    employee = Employee.objects.all()
    context = {
        'employee' : employee
    }
    return render(request, 'employee/employee.html', context)

def add_employee(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        designation = request.POST.get('designation')
        department = request.POST.get('department')
        salary = request.POST.get('salary')
        joining_date = request.POST.get('joining_date')
        address = request.POST.get('address')
        
        Employee(
            first_name = first_name,
            last_name = last_name,
            email = email,
            phone = phone,
            designation = designation,
            department = department,
            salary = salary,
            joining_date = joining_date,
            address = address
        ).save()
        return redirect('employee_view')

    return render(request, 'employee/add-employee.html')
