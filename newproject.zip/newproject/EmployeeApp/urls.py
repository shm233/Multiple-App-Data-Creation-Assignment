from django.urls import path
from EmployeeApp.views import *

urlpatterns = [
    path('employee/', employee_view, name='employee_view'),
    path('add-employee/', add_employee, name='add_employee'),
]
