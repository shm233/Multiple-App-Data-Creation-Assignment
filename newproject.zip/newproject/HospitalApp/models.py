from django.db import models

# Create your models here.

class Patient(models.Model):
    GENDER = [
        ('male', 'male'),
        ('female', 'female')
    ]
    BLOOD_GROUP = [
        ('A', 'A'),
        ('B', 'B'),
        ('O', 'O')
    ]
    first_name = models.CharField(max_length=255, null=True)
    age = models.PositiveIntegerField(null=True)
    gender = models.CharField(max_length=10, choices=GENDER, null=True)
    blood_group = models.CharField(max_length=5, choices=BLOOD_GROUP, null=True)
    phone = models.IntegerField(null=True)
    address = models.TextField(null=True)
    admission_date = models.DateTimeField(null=True)
    
    def __str__(self):
        return f"{self.first_name}---{self.admission_date}"
