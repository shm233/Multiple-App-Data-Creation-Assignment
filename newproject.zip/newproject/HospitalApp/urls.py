from django.urls import path
from HospitalApp.views import *

urlpatterns = [
    path('patient/', patient_view, name='patient_view'),
    path('add-patient/', add_patient, name='add_patient')
]
