from django.shortcuts import render, redirect
from HospitalApp.models import *

# Create your views here.

def patient_view(request):
    patient = Patient.objects.all()
    
    context = {
        'patient' : patient
    }
    return render(request, 'hospital/patient.html', context)

def add_patient(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        age = request.POST.get('age')
        gender = request.POST.get('gender')
        blood_group = request.POST.get('blood_group')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        admission_date = request.POST.get('admission_date')
        
        Patient(
            first_name = first_name,
            age = age,
            gender = gender,
            blood_group = blood_group,
            phone = phone,
            address = address,
            admission_date = admission_date
        ).save()
        return redirect('patient_view')
    return render(request, 'hospital/add-patient.html')
