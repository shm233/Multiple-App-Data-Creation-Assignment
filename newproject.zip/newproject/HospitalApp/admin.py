from django.contrib import admin
from HospitalApp.models import *

# Register your models here.

admin.site.register(Patient)
