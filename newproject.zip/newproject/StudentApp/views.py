from django.shortcuts import render, redirect
from django.db.models import Q
from StudentApp.models import *

# Create your views here.

def dashboard_view(request):
    return render(request, 'dashboard.html')

def student_view(request):
    student = Student.objects.all()
    
    context = {
        'student' : student
    }
    return render(request, 'student/student.html', context)

def add_student(request):
    if request.method == 'POST':
        student_id = request.POST.get('student_id')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        gender = request.POST.get('gender')
        date_of_birth = request.POST.get('date_of_birth')
        department = request.POST.get('department')
        address = request.POST.get('address')
        admission_date = request.POST.get('admission_date')
        
        Student(
            student_id = student_id,
            first_name = first_name,
            last_name = last_name,
            email = email,
            phone = phone,
            gender = gender,
            date_of_birth = date_of_birth,
            department = department,
            address = address,
            admission_date = admission_date
        ).save()
        return redirect('student_view')
    
    return render(request, 'student/add-student.html')
