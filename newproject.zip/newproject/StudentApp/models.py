from django.db import models

# Create your models here.

class Student(models.Model):
    GENDER = [
        ('male' , 'male'),
        ('female' , 'female'),
        ('non-binary' , 'non-binary')
    ]
    student_id = models.CharField(unique=True, null=True)
    first_name = models.CharField(max_length=255, null=True)
    last_name = models.CharField(max_length=255, null=True)
    email = models.EmailField(null=True)
    phone = models.CharField(null=True)
    gender = models.CharField(max_length=10, choices=GENDER, null=True)
    date_of_birth = models.DateField(null=True)
    department = models.CharField(max_length=255, null=True)
    address = models.TextField(null=True)
    admission_date = models.DateTimeField(auto_now_add=True, null=True)
    
    def __str__(self):
        return f"{self.first_name}---{self.email}"
