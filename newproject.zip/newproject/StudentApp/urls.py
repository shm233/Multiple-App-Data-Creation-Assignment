from django.urls import path
from StudentApp.views import *

urlpatterns = [
    path('', dashboard_view, name='dashboard_view'),
    path('students/', student_view, name='student_view'),
    path('add-student/', add_student, name='add_student'),
]
