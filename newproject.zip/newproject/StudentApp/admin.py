from django.contrib import admin
from StudentApp.models import *

# Register your models here.

admin.site.register(Student)
