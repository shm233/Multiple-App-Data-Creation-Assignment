from django.urls import path
from LibraryApp.views import *

urlpatterns = [
    path('book/',book_view, name='book_view'),
    path('add_book/', add_book, name='add_book'),
]
