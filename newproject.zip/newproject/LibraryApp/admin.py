from django.contrib import admin
from LibraryApp.models import *

# Register your models here.

admin.site.register(Book)
