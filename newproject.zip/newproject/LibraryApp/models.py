from django.db import models

# Create your models here.

class Book(models.Model):
    title = models.CharField(max_length=255, null=True)
    author = models.CharField(max_length=255, null=True)
    publisher = models.CharField(max_length=255, null=True)
    ISBN = models.PositiveIntegerField(null=True)
    category = models.CharField(max_length=255, null=True)
    publication_year = models.DateField(null=True)
    price = models.FloatField(null=True)
    
    def __str__(self):
        return f"{self.title}---{self.author}"
