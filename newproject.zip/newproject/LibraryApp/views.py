from django.shortcuts import render, redirect
from LibraryApp.models import *

# Create your views here.

def book_view(request):
    book = Book.objects.all()
    context = {
        'book' : book
    }
    return render(request, 'library/book.html', context)

def add_book(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        author = request.POST.get('author')
        publisher = request.POST.get('publisher')
        isbn = request.POST.get('isbn')
        category = request.POST.get('category')
        publication_year = request.POST.get('publication_year')
        price = request.POST.get('price')
        
        Book(
            title = title,
            author = author,
            publisher = publisher,
            ISBN = isbn,
            category = category,
            publication_year = publication_year,
            price = price            
        ).save()
        return redirect('book_view')      
    return render(request, 'library/add-book.html')
