from django.shortcuts import render,redirect
from ProductApp.models import *

# Create your views here.

def product_view(request):
    product = Product.objects.all()
    context = {
        'product' : product
    }
    return render(request, 'product/product.html' ,context)

def add_product(request):
    if request.method == 'POST':
        product_name = request.POST.get('product_name')
        category = request.POST.get('category')
        brand = request.POST.get('brand')
        price = request.POST.get('price')
        quantity = request.POST.get('quantity')
        manufacture_date = request.POST.get('manufacture_date')
        expiry_date = request.POST.get('expiry_date')
        
        Product(
            product_name = product_name,
            category = category,
            brand = brand,
            price = price,
            quantity = quantity,
            manufacture_date = manufacture_date,
            expiry_date = expiry_date
        ).save()
        return redirect('product_view')
    return render(request,'product/add-product.html')
