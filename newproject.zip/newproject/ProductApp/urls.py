from django.urls import path
from ProductApp.views import *

urlpatterns = [
   path('product/', product_view, name='product_view'),
   path('add-product/', add_product, name='add_product'),
]
