from django.db import models

# Create your models here.

class Product(models.Model):
    product_name = models.CharField(max_length=255, null=True)
    category = models.CharField(max_length=255, null=True)
    brand = models.CharField(max_length=255, null=True)
    price = models.FloatField(null=True)
    quantity = models.PositiveIntegerField(null=True)
    manufacture_date = models.DateTimeField(auto_now_add=True, null=True)  
    expiry_date = models.DateTimeField(null=True)
    
    def __str__(self):
        return f"{self.product_name}---{self.brand}"
