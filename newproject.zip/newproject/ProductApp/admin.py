from django.contrib import admin
from ProductApp.models import *

# Register your models here.

admin.site.register(Product)
